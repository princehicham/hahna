<div>

    <!-- Validation Errors -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    
    <div class="row">
        <div class="col-12">

	        <!-- begin:Add new footer translations -->
	        <div class="dropdown d-flex">
	          <a class="btn bg-gradient-info dropdown-toggle " data-bs-toggle="dropdown" id="navbarDropdownMenuLang">
	             <?php echo e(__('Add New Translations')); ?>

	          </a>
	          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLang">
	             <?php $__currentLoopData = localization()->getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                  <li>
	                      <a class="dropdown-item" href="<?php echo e(localization()->getLocalizedURL($properties->key(), route('create-footer-translations'), [], true)); ?>">
	                        <img src="<?php echo e(asset('assets/img/flags/' . $properties->key() . '.svg')); ?>" class="lang-menu me-1 my-auto"> <?php echo e($properties->native()); ?>

	                      </a>
	                  </li>
	              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	          </ul>
	        </div>
	        <!-- begin:Add new footer translations -->

            <div class="card">
              <div class="card-body">
	            	<div class="table-responsive">
	            		<table class="table align-items-center mb-0">
	                        <tbody>
	            				<tr>
	            					<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo e(__('Language')); ?></th>
	            					<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo e(__('Action')); ?></th>
	            				</tr>

	                            <?php if( $footer_translations->isNotEmpty() ): ?>

	                                <?php $__currentLoopData = $footer_translations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer_translation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	                                    <tr>
	                                        <td class="align-middle py-3">
	                                        	<img src="<?php echo e(asset('assets/img/flags/' . $footer_translation->locale . '.svg')); ?>" class="lang-menu mx-auto"> 
	                                        	<span><?php echo e(localization()->getSupportedLocales()[$footer_translation->locale]->native()); ?></span>
	                                        </td>
	                                        <td class="align-middle w-25">
	                                            <a href="<?php echo e(localization()->getLocalizedURL($footer_translation->locale, route('edit-footer-translations', $footer_translation->id), [], true)); ?>" class="btn btn-sm btn-primary mb-0" title="<?php echo e(__('Edit')); ?>"><i class="fas fa-edit"></i> <?php echo e(__('Edit')); ?></a>
	                                            <a wire:click="onDeleteConfirmFooterTranslation( <?php echo e($footer_translation->id); ?> )" class="btn btn-sm btn-danger mb-0" title="<?php echo e(__('Delete')); ?>"><i class="fas fa-trash fa-fw"></i> <?php echo e(__('Delete')); ?></a>
	                                        </td>
	                                    </tr>

	                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	                            <?php else: ?>

	                                <tr>
	                                    <td><?php echo e(__('No record found')); ?></td>
	                                </tr>
									
	                            <?php endif; ?>

	                        </tbody>

	            		</table>
	            	</div>

					<div class="float-end">
						<!-- begin:pagination -->
						<?php echo e($footer_translations->links()); ?>

						<!-- begin:pagination -->
					</div>
				</div>
            </div>
        </div>

    </div>

</div>
<script>
(function( $ ) {
    "use strict";
	
	document.addEventListener('livewire:load', function () {
		
		window.addEventListener('swal:modal', event => {

			const swalWithBootstrapButtons = Swal.mixin({
			  customClass: {
				confirmButton: 'btn bg-gradient-success',
				cancelButton: 'btn bg-gradient-danger'
			  },
			  buttonsStyling: false
			})

			swalWithBootstrapButtons.fire({
			  title: event.detail.title,
			  text: event.detail.text,
			  icon: event.detail.type,
			  showCancelButton: true,
			  confirmButtonText: "<?php echo e(__('Yes, delete it!')); ?>",
			  cancelButtonText: "<?php echo e(__('Cancel')); ?>"
			}).then((result) => {
			  if (result.isConfirmed) {
				window.livewire.emit('onDeleteFooterTranslation', event.detail.id)
			  }
			});

		});

		window.addEventListener('alert', event => {
			toastr[event.detail.type](event.detail.message);
		});

	});

})( jQuery );
</script><?php /**PATH C:\xampp\htdocs\laravel\vidclear\components\resources\views/livewire/admin/settings/footer.blade.php ENDPATH**/ ?>