<div>

	<div class="card">
		<div class="card-body">

			<div class="table-responsive">
				<table class="table align-items-center mb-0">
					<tbody>
						<tr>
							<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo e(__('Link')); ?></th>
							<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo e(__('Date')); ?></th>
							<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo e(__('Action')); ?></th>
						</tr>
						<?php if( $reports->isEmpty() == false ): ?>

							<?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<tr>
								<td class="align-middle">
									<p class="text-xs font-weight-bold mb-0 ">

										<div class="form-group">
											<a href="<?php echo e($report->link); ?>" target="_blank" class="input-group">
												<input type="text" value="<?php echo e($report->link); ?>" class="form-control cursor-pointer" readonly>
												<span class="input-group-text"><i class="fas fa-external-link-alt"></i></span>
											</a>
										</div>

									</p>
								</td>
								<td class="align-middle">
									<p class="text-xs font-weight-bold mb-0"><?php echo e($report->created_at); ?></p>
								</td>
								<td class="align-middle">
									<a wire:click="onDeleteConfirm( <?php echo e($report->id); ?> )" class="btn btn-danger" title="Delete"><i class="fas fa-trash"></i></a>
								</td>
							</tr>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<?php else: ?>

							<tr>
								<td class="align-middle"><?php echo e(__('No record found')); ?></td>
							</tr>

						<?php endif; ?>

					</tbody>
				</table>
			</div>

			<div class="float-end">
				<!-- begin:pagination -->
				<?php echo e($reports->links()); ?>

				<!-- begin:pagination -->
			</div>

		</div>
	</div>
	
</div>

<script>
(function( $ ) {
	"use strict";

	document.addEventListener('livewire:load', function () {
		
		window.addEventListener('swal:modal', event => {

			const swalWithBootstrapButtons = Swal.mixin({
			  customClass: {
				confirmButton: 'btn bg-gradient-success',
				cancelButton: 'btn bg-gradient-danger'
			  },
			  buttonsStyling: false
			})

		swalWithBootstrapButtons.fire({
			  title: event.detail.title,
			  text: event.detail.text,
			  icon: event.detail.type,
			  showCancelButton: true,
			  confirmButtonText: "<?php echo e(__('Yes, delete it!')); ?>",
			  cancelButtonText: "<?php echo e(__('Cancel')); ?>"
			}).then((result) => {
			  if (result.isConfirmed) {
				window.livewire.emit('onDeleteReport', event.detail.id)
			  }
			});

		});

		window.addEventListener('alert', event => {
			toastr[event.detail.type](event.detail.message);
		});

	});

})( jQuery );
</script><?php /**PATH C:\xampp\htdocs\laravel\vidclear\components\resources\views/livewire/admin/report/showlist.blade.php ENDPATH**/ ?>