<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">


    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php switch( $page->type ):
            case ('default'): ?>
            <?php case ('downloader'): ?>
            <?php case ('contact'): ?>

                 <?php $__currentLoopData = localization()->getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <url>
                        <loc><?php echo e(localization()->getLocalizedURL($properties->key(), route('home') . '/' . $page->slug, [], false)); ?></loc>
                        <lastmod><?php echo e($page->updated_at->tz('UTC')->toAtomString()); ?></lastmod>
                        <priority>1.00</priority>
                    </url>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php break; ?>

            <?php case ('home'): ?>

                 <?php $__currentLoopData = localization()->getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <url>
                        <loc><?php echo e(localization()->getLocalizedURL($properties->key(), route('home'), [], false)); ?></loc>
                        <lastmod><?php echo e($page->updated_at->tz('UTC')->toAtomString()); ?></lastmod>
                        <priority>1.00</priority>
                    </url>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php break; ?>

            <?php default: ?>
        <?php endswitch; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</urlset><?php /**PATH C:\xampp\htdocs\laravel\vidclear\components\resources\views/frontend/sitemap.blade.php ENDPATH**/ ?>