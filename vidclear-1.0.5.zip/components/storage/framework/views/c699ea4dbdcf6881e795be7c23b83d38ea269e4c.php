<?php
	echo '<pre>';
	print_r($menus);
	echo '</pre>';
?><?php /**PATH C:\xampp\htdocs\laravel\vidclear\components\resources\views/test.blade.php ENDPATH**/ ?>