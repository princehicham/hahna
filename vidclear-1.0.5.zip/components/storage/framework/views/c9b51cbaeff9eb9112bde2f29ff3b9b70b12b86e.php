<div>

	<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3 bg-white" id="sidenav-main">
		
		<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.sidenav-header','data' => []]); ?>
<?php $component->withName('admin.sidenav-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

		<hr class="horizontal dark mt-0">

		<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.sidebar','data' => []]); ?>
<?php $component->withName('admin.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
		
	</aside>
	
	<main class="main-content mt-1 border-radius-lg">
		    <!-- Navbar -->
		    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="false">
		     <div class="container-fluid py-1 px-3">

		        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.breadcrumbs','data' => []]); ?>
<?php $component->withName('admin.breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

		        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.navright','data' => []]); ?>
<?php $component->withName('admin.navright'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

		     </div>
		   </nav>
		  <!-- End Navbar -->

			<div class="container-fluid py-4">
			  <div class="row">
			    <div class="col">

			      <div class="card card-body blur shadow-blur">
			        <div class="row gx-4">

			          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.profile.avatar')->html();
} elseif ($_instance->childHasBeenRendered('0CyrgVv')) {
    $componentId = $_instance->getRenderedChildComponentId('0CyrgVv');
    $componentTag = $_instance->getRenderedChildComponentTagName('0CyrgVv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0CyrgVv');
} else {
    $response = \Livewire\Livewire::mount('admin.profile.avatar');
    $html = $response->html();
    $_instance->logRenderedChild('0CyrgVv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

			        </div>
			      </div>

			      <div class="row py-4">
			        <div class="col-12">

			        	<div class="tab-content">

			        		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.profile.overview')->html();
} elseif ($_instance->childHasBeenRendered('i1cwrLy')) {
    $componentId = $_instance->getRenderedChildComponentId('i1cwrLy');
    $componentTag = $_instance->getRenderedChildComponentTagName('i1cwrLy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('i1cwrLy');
} else {
    $response = \Livewire\Livewire::mount('admin.profile.overview');
    $html = $response->html();
    $_instance->logRenderedChild('i1cwrLy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

			        		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.profile.update-profile')->html();
} elseif ($_instance->childHasBeenRendered('RrxjOJU')) {
    $componentId = $_instance->getRenderedChildComponentId('RrxjOJU');
    $componentTag = $_instance->getRenderedChildComponentTagName('RrxjOJU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('RrxjOJU');
} else {
    $response = \Livewire\Livewire::mount('admin.profile.update-profile');
    $html = $response->html();
    $_instance->logRenderedChild('RrxjOJU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

			        		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.profile.change-password')->html();
} elseif ($_instance->childHasBeenRendered('9CjcngM')) {
    $componentId = $_instance->getRenderedChildComponentId('9CjcngM');
    $componentTag = $_instance->getRenderedChildComponentTagName('9CjcngM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9CjcngM');
} else {
    $response = \Livewire\Livewire::mount('admin.profile.change-password');
    $html = $response->html();
    $_instance->logRenderedChild('9CjcngM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

					    </div>

			        </div>
				  </div>


				</div>
			  </div>
			</div>
			
		<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.footer','data' => []]); ?>
<?php $component->withName('admin.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

	</main>

</div>

<script src="<?php echo e(asset('components/public/vendor/laravel-filemanager/js/stand-alone-button.js')); ?>"></script>
<script>
(function( $ ) {
	"use strict";
	
    document.addEventListener('livewire:load', function () {

		jQuery('.edit-avatar').filemanager('image', {prefix: '<?php echo e(url('/')); ?>/filemanager'});

		jQuery('input#avatar').change(function() { 
			window.livewire.emit('onSetAvatar', this.value)
		});

		window.addEventListener('alert', event => {
			toastr[event.detail.type](event.detail.message);
		});
	
    });

})( jQuery );
</script><?php /**PATH C:\xampp\htdocs\laravel\vidclear\components\resources\views/livewire/admin/profile.blade.php ENDPATH**/ ?>