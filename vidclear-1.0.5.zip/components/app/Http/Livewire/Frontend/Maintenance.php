<?php

namespace App\Http\Livewire\Frontend;

use Livewire\Component;

class Maintenance extends Component
{
    public function render()
    {
        return view('livewire.frontend.maintenance');
    }
}
